import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BeatPadIDEGUI extends JFrame {
    private BeatPadIDE musicIDE;
    private JTextField noteNameField;
    private JTextField durationField;

    public BeatPadIDEGUI() {
        // Initialize the MusicIDE.
        musicIDE = new BeatPadIDE();

        // Set up the JFrame.
        setTitle("BeatPad Chord Generator");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        // Add the components.
        add(new JLabel("Note Name: "));
        noteNameField = new JTextField();
        add(noteNameField);

        add(new JLabel("Duration (ms): "));
        durationField = new JTextField();
        add(durationField);

        JButton addButton = new JButton("Add Note");
        addButton.addActionListener(new AddNoteAction());
        add(addButton);

        JButton playButton = new JButton("Play Sequence");
        playButton.addActionListener(new PlaySequenceAction());
        add(playButton);
    }

    private class AddNoteAction implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            String noteName = noteNameField.getText();
            int duration = Integer.parseInt(durationField.getText());
            Note note = new Note(noteName, duration);
            musicIDE.addNoteToSequence(note);
        }
    }

    private class PlaySequenceAction implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                musicIDE.playSequence();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            BeatPadIDEGUI ex = new BeatPadIDEGUI();
            ex.setVisible(true);
        });
    }
}