import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DrumPad {
    private JFrame frame;
    private boolean isRecording = false;
    private LinkedList<Action> actionLinkedList = new LinkedList<>();

    public DrumPad() {
        frame = new JFrame("BeatPad");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400,400);

        JPanel mainPanel = new JPanel(new BorderLayout());
        frame.add(mainPanel);

        JPanel drumPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        drumPanel.setBackground(Color.darkGray);
        mainPanel.add(drumPanel, BorderLayout.NORTH);

        DrumButton button1 = new DrumButton("HH", "sounds/hh.wav", this);
        DrumButton button2 = new DrumButton("Kick", "sounds/kick.wav", this);
        DrumButton button3 = new DrumButton("Snare", "sounds/snare.wav", this);
        DrumButton button4 = new DrumButton("Clap", "sounds/clap.wav", this);

        drumPanel.add(button1);
        drumPanel.add(button2);
        drumPanel.add(button3);
        drumPanel.add(button4);

        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(Color.lightGray);
        mainPanel.add(controlPanel,BorderLayout.CENTER);

        JButton recordButton = new JButton("Start Recording");
        recordButton.setBackground(Color.red);
        recordButton.addActionListener(e -> {
            isRecording = true;
            actionLinkedList.clear();
            recordButton.setText("Recording");
        });
        controlPanel.add(recordButton);


        JButton playButton = new JButton("Stop and Play Back");
        playButton.addActionListener(e -> {
            isRecording = false;
            recordButton.setText("Start Recording");
            for (Action a : actionLinkedList) {
                try {
                    Thread.sleep(a.time);
                    a.button.playSound();
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        });
        controlPanel.add(playButton);
    }
    public void show() {
        frame.setVisible(true);
    }
    public void recordAction(DrumButton b, long time) {
        if (isRecording) {
            actionLinkedList.add(new Action(b, time));
        }
    }
    private static class Action {
        DrumButton button;
        long time;

        Action(DrumButton button, long time) {
            this.button = button;
            this.time = time;
        }
    }
}
