import java.util.ArrayList;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiEvent;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequencer;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.Track;

public class BeatPadIDE {

    private NoteSequence sequence;

    public BeatPadIDE() {
        this.sequence = new NoteSequence();
    }

    public void addNoteToSequence(Note n) {
        sequence.add(n);
    }

    public void playSequence() throws MidiUnavailableException, InvalidMidiDataException {
        // Get a Sequencer and open it.
        Sequencer sequencer = MidiSystem.getSequencer();
        sequencer.open();

        // Create a sequence object to hold the notes.
        javax.sound.midi.Sequence midiSequence = new javax.sound.midi.Sequence(
                javax.sound.midi.Sequence.PPQ, 4);

        // Create a track from the sequence.
        Track track = midiSequence.createTrack();

        for (Note note : sequence.getNotes()) {
            // Add note events to the track.
            int key = NoteToMidiMapper.map(
                    note.getName()); // You will need to implement the NoteToMidiMapper class.
            int velocity = 64; // Volume
            int duration = note.getDuration();

            ShortMessage onMessage = new ShortMessage();
            onMessage.setMessage(ShortMessage.NOTE_ON, 0, key, velocity);
            MidiEvent onEvent = new MidiEvent(onMessage, 0);
            track.add(onEvent);

            ShortMessage offMessage = new ShortMessage();
            offMessage.setMessage(ShortMessage.NOTE_OFF, 0, key, velocity);
            MidiEvent offEvent = new MidiEvent(offMessage, duration);
            track.add(offEvent);
        }
        sequencer.setSequence(midiSequence);
        sequencer.start();
    }
}
