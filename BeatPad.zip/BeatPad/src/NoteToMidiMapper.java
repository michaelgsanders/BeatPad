import java.util.HashMap;
import java.util.Map;

public class NoteToMidiMapper {
    private static final Map<String, Integer> NOTE_TO_MIDI_MAP;

    static {
        NOTE_TO_MIDI_MAP = new HashMap<>();
        NOTE_TO_MIDI_MAP.put("C", 0);
        NOTE_TO_MIDI_MAP.put("C#", 1);
        NOTE_TO_MIDI_MAP.put("Db", 1);
        NOTE_TO_MIDI_MAP.put("D", 2);
        NOTE_TO_MIDI_MAP.put("D#", 3);
        NOTE_TO_MIDI_MAP.put("Eb", 3);
        NOTE_TO_MIDI_MAP.put("E", 4);
        NOTE_TO_MIDI_MAP.put("F", 5);
        NOTE_TO_MIDI_MAP.put("F#", 6);
        NOTE_TO_MIDI_MAP.put("Gb", 6);
        NOTE_TO_MIDI_MAP.put("G", 7);
        NOTE_TO_MIDI_MAP.put("G#", 8);
        NOTE_TO_MIDI_MAP.put("Ab", 8);
        NOTE_TO_MIDI_MAP.put("A", 9);
        NOTE_TO_MIDI_MAP.put("A#", 10);
        NOTE_TO_MIDI_MAP.put("Bb", 10);
        NOTE_TO_MIDI_MAP.put("B", 11);
    }

    public static int map(String note) {
        if (note == null || note.length() < 2) {
            throw new IllegalArgumentException("Invalid note: " + note);
        }

        String notePart = note.substring(0, note.length() - 1);
        String octavePart = note.substring(note.length() - 1);

        Integer noteNumber = NOTE_TO_MIDI_MAP.get(notePart);
        if (noteNumber == null) {
            throw new IllegalArgumentException("Invalid note: " + note);
        }

        int octave;
        try {
            octave = Integer.parseInt(octavePart);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid octave: " + note, e);
        }

        return noteNumber + octave * 12;
    }
}