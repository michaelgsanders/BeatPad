import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;

public class DrumButton extends JButton {

    private String soundFileName;
    private DrumPad drumPad;
    private long startTime;

    public DrumButton(String label, String soundFileName, DrumPad drumPad) {
        super(label);
        this.soundFileName = soundFileName;
        this.drumPad = drumPad;
        this.startTime = System.currentTimeMillis();
        this.setBackground(Color.gray);
        this.setForeground(Color.white);
        this.setFont(new Font("Arial",Font.PLAIN,20));
        this.addActionListener(e -> {
            playSound();
            drumPad.recordAction(DrumButton.this, ((System.currentTimeMillis() - startTime) / 10));
        });
    }
    public void playSound() {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundFileName).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e){
            e.printStackTrace();        }
    }
    public String getSoundFileName() {
        return this.soundFileName;
    }
}
