public class Main {

    public static void main(String[] args) {
        DrumPad drumPad = new DrumPad();
        drumPad.show();
        BeatPadIDEGUI ex = new BeatPadIDEGUI();
        ex.setVisible(true);
    }

}