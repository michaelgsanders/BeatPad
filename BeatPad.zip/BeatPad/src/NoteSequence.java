import java.util.ArrayList;

public class NoteSequence {
    private ArrayList<Note> notes = new ArrayList<>();


    public void add(Note n) {
        notes.add(n);
    }

    public ArrayList<Note> getNotes() {
        return notes;
    }
}
